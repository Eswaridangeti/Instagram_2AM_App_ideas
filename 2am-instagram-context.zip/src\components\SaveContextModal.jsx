import React, { useState, useEffect, useRef } from 'react';
import { CloseIcon, BookmarkIcon, NoteContextIcon } from './InstagramIcons';

export function SaveContextModal({ post, isOpen, onClose, onSaveContext, onUnsave }) {
  const [note, setNote] = useState('');
  const textareaRef = useRef(null);

  useEffect(() => {
    if (post) {
      setNote(post.savedNote || '');
      // Focus textarea on modal open
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
        }
      }, 100);
    }
  }, [post, isOpen]);

  if (!isOpen || !post) return null;

  const quickTags = [
    '💡 Design Inspo',
    '🎨 Color Palette',
    '🛠 Code to Try',
    '📐 Layout Idea',
    '📚 Reference',
    '✨ Aesthetic'
  ];

  const handleAddTag = (tag) => {
    if (!note) {
      setNote(`${tag}: `);
    } else {
      setNote(`${note} | ${tag}`);
    }
    textareaRef.current?.focus();
  };

  const handleSave = () => {
    onSaveContext(post.id, note.trim());
    onClose();
  };

  const handleSkipOrCancel = () => {
    // Keeps it saved normally without altering note
    onClose();
  };

  return (
    <div 
      className="ig-modal-backdrop animate-fade-in"
      onClick={handleSkipOrCancel}
    >
      <div 
        className="ig-modal-container animate-modal-desktop"
        onClick={(e) => e.stopPropagation()}
        style={{ position: 'relative' }}
      >
        {/* Mobile handle indicator */}
        <div 
          style={{
            width: 36,
            height: 4,
            background: '#dbdbdb',
            borderRadius: 2,
            margin: '10px auto 0 auto'
          }}
          className="mobile-only-handle"
        />

        {/* Modal Header */}
        <div className="ig-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div 
              style={{
                width: 28,
                height: 28,
                borderRadius: '50%',
                background: '#f0f9ff',
                color: '#0095f6',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <BookmarkIcon filled size={16} />
            </div>
            <h3 className="ig-modal-title">Save With Context</h3>
          </div>
          <button 
            onClick={handleSkipOrCancel}
            style={{ color: 'var(--ig-secondary-text)', padding: 4 }}
          >
            <CloseIcon size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="ig-modal-body">
          {/* Post preview pill */}
          <div 
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              background: 'var(--ig-secondary-bg)',
              padding: '8px 12px',
              borderRadius: 8,
              border: '1px solid var(--ig-border-light)'
            }}
          >
            <img 
              src={post.image} 
              alt={post.username} 
              style={{ width: 44, height: 44, borderRadius: 6, objectFit: 'cover' }} 
            />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>@{post.username}</div>
              <div 
                style={{
                  fontSize: 12,
                  color: 'var(--ig-secondary-text)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}
              >
                {post.caption}
              </div>
            </div>
          </div>

          {/* Question Prompt */}
          <div>
            <label 
              style={{
                display: 'block',
                fontSize: 15,
                fontWeight: 600,
                color: 'var(--ig-primary-text)',
                marginBottom: 4
              }}
            >
              Why are you saving this?
            </label>
            <p style={{ fontSize: 12, color: 'var(--ig-secondary-text)', marginBottom: 12 }}>
              Add a personal note so you remember why this caught your eye. (Optional)
            </p>

            {/* Quick Inspiration Tags */}
            <div className="ig-context-tags" style={{ marginBottom: 12 }}>
              {quickTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  className="ig-tag-btn"
                  onClick={() => handleAddTag(tag)}
                >
                  {tag}
                </button>
              ))}
            </div>

            {/* Textarea */}
            <textarea
              ref={textareaRef}
              className="ig-context-textarea"
              placeholder="e.g. Love this UI — want to try something similar for my portfolio."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
            />
          </div>

          {/* Subtle watermark indication inside modal */}
          <div 
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              fontSize: 11,
              color: '#8e8e8e',
              paddingTop: 4
            }}
          >
            <span>Saved posts are private to your collection</span>
            <span style={{ opacity: 0.65 }}>2AM App Ideas</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="ig-modal-footer">
          {post.isSaved && (
            <button
              type="button"
              onClick={() => {
                onUnsave(post.id);
                onClose();
              }}
              style={{
                marginRight: 'auto',
                fontSize: 13,
                color: '#ed4956',
                fontWeight: 600,
                padding: '6px 8px'
              }}
            >
              Remove from Saved
            </button>
          )}

          <button 
            type="button" 
            className="ig-btn-secondary" 
            onClick={handleSkipOrCancel}
          >
            {note ? 'Cancel' : 'Skip Note'}
          </button>

          <button 
            type="button" 
            className="ig-btn-primary" 
            onClick={handleSave}
          >
            {note ? 'Save Note' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
}
