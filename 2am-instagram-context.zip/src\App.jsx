import React, { useState, useEffect } from 'react';
import { MOCK_POSTS, MOCK_STORIES, CURRENT_USER } from './data/mockData';
import { DesktopSidebar } from './components/DesktopSidebar';
import { MobileHeader } from './components/MobileHeader';
import { MobileBottomNav } from './components/MobileBottomNav';
import { StoriesRow } from './components/StoriesRow';
import { StoryViewer } from './components/StoryViewer';
import { PostCard } from './components/PostCard';
import { SaveContextModal } from './components/SaveContextModal';
import { SavedPage } from './components/SavedPage';
import { RightSidebar } from './components/RightSidebar';
import { PostOptionsModal } from './components/PostOptionsModal';
import { CreatePostModal } from './components/CreatePostModal';
import { Toast } from './components/Toast';
import { Watermark } from './components/Watermark';

const STORAGE_KEY = '2am_instagram_context_posts_v3';

export default function App() {
  const [posts, setPosts] = useState(() => {
    try {
      const savedData = localStorage.getItem(STORAGE_KEY);
      if (savedData) {
        return JSON.parse(savedData);
      }
    } catch (e) {
      console.error('Failed reading localStorage', e);
    }
    // Default seeded state
    return MOCK_POSTS.map(p => ({
      ...p,
      isLiked: false,
      isSaved: !!p.initialSaved,
      savedNote: p.initialNote || '',
      userComments: []
    }));
  });

  const [currentView, setCurrentView] = useState('feed'); // 'feed' | 'saved'
  const [activeStory, setActiveStory] = useState(null);
  const [saveModalPost, setSaveModalPost] = useState(null);
  const [optionsModalPost, setOptionsModalPost] = useState(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [toast, setToast] = useState({
    isVisible: false,
    message: '',
    actionText: '',
    onAction: null
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
    } catch (e) {
      console.error('Failed writing to localStorage', e);
    }
  }, [posts]);

  // Show toast utility
  const showToast = (message, actionText = '', onAction = null) => {
    setToast({
      isVisible: true,
      message,
      actionText,
      onAction
    });
    setTimeout(() => {
      setToast(prev => ({ ...prev, isVisible: false }));
    }, 4000);
  };

  // Toggle Like on post
  const handleToggleLike = (postId) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return { ...p, isLiked: !p.isLiked };
      }
      return p;
    }));
  };

  // Open Save Modal (Step 1: Save immediately; Step 2: Open modal for optional context note)
  const handleOpenSaveModal = (post) => {
    if (!post.isSaved) {
      // Step 1: Save immediately!
      setPosts(prev => prev.map(p => {
        if (p.id === post.id) {
          return { ...p, isSaved: true };
        }
        return p;
      }));

      // Step 2: Open Instagram-style modal asking "Why are you saving this?"
      setSaveModalPost({ ...post, isSaved: true });

      showToast('Saved to your collection', 'View Saved', () => {
        setCurrentView('saved');
      });
    } else {
      // Already saved: open modal to edit note or unsave
      setSaveModalPost(post);
    }
  };

  // Save context note
  const handleSaveContext = (postId, note) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          isSaved: true,
          savedNote: note
        };
      }
      return p;
    }));

    if (note) {
      showToast('Saved with context to your collection', 'View Saved', () => {
        setCurrentView('saved');
      });
    } else {
      showToast('Saved to your collection');
    }
  };

  // Unsave post
  const handleUnsave = (postId) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          isSaved: false,
          savedNote: ''
        };
      }
      return p;
    }));
    showToast('Removed from Saved');
  };

  // Add Comment
  const handleAddComment = (postId, text) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          userComments: [...(p.userComments || []), text]
        };
      }
      return p;
    }));
    showToast('Comment posted');
  };

  // Create Post
  const handleCreatePost = (newPostData) => {
    const created = {
      ...newPostData,
      id: `post-${Date.now()}`,
      timestamp: 'JUST NOW',
      isLiked: false,
      isSaved: false,
      savedNote: '',
      commentsCount: 0,
      recentComments: [],
      userComments: []
    };
    setPosts(prev => [created, ...prev]);
    showToast('Post shared to your feed');
  };

  const savedPosts = posts.filter(p => p.isSaved);

  return (
    <div className="app-layout">
      {/* Desktop Sidebar (visible on md/lg screens) */}
      <DesktopSidebar
        currentView={currentView}
        setCurrentView={setCurrentView}
        savedCount={savedPosts.length}
        currentUser={CURRENT_USER}
        onOpenCreate={() => setIsCreateOpen(true)}
      />

      {/* Mobile Top Header (visible on screens < 768px) */}
      <MobileHeader
        currentView={currentView}
        setCurrentView={setCurrentView}
        savedCount={savedPosts.length}
      />

      {/* Main Content Area */}
      <main className="ig-main-content">
        {currentView === 'feed' ? (
          <div className="ig-feed-layout">
            <div className="ig-feed-center">
              {/* Stories Carousel */}
              <StoriesRow
                stories={MOCK_STORIES}
                onSelectStory={(story) => setActiveStory(story)}
              />

              {/* Home Feed Posts */}
              {posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  currentUser={CURRENT_USER}
                  onToggleLike={handleToggleLike}
                  onOpenSaveModal={handleOpenSaveModal}
                  onOpenOptions={(p) => setOptionsModalPost(p)}
                  onAddComment={handleAddComment}
                />
              ))}

              {/* Feed End message */}
              <div 
                style={{
                  textAlign: 'center',
                  padding: '30px 10px 60px 10px',
                  color: 'var(--ig-secondary-text)',
                  fontSize: 13
                }}
              >
                <div style={{ fontWeight: 600, color: 'var(--ig-primary-text)', marginBottom: 4 }}>
                  You're all caught up
                </div>
                <div>You've seen all new posts from the last 3 days.</div>
                <div 
                  className="watermark-subtle" 
                  style={{ marginTop: 12, display: 'inline-flex' }}
                >
                  2AM App Ideas • #01
                </div>
              </div>
            </div>

            {/* Desktop Right Sidebar with Suggestions & Profile Switch */}
            <RightSidebar
              currentUser={CURRENT_USER}
              onOpenProfile={() => setCurrentView('saved')}
            />
          </div>
        ) : (
          /* Saved View (Core Feature Collection) */
          <SavedPage
            savedPosts={savedPosts}
            onBackToFeed={() => setCurrentView('feed')}
            onOpenSaveModal={(p) => setSaveModalPost(p)}
            onUnsavePost={handleUnsave}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (screens < 768px) */}
      <MobileBottomNav
        currentView={currentView}
        setCurrentView={setCurrentView}
        currentUser={CURRENT_USER}
        savedCount={savedPosts.length}
        onOpenCreate={() => setIsCreateOpen(true)}
      />

      {/* Story Viewer Modal */}
      {activeStory && (
        <StoryViewer
          story={activeStory}
          allStories={MOCK_STORIES}
          onClose={() => setActiveStory(null)}
          onSelectStory={(s) => setActiveStory(s)}
        />
      )}

      {/* Save With Context Modal / Bottom Sheet */}
      <SaveContextModal
        post={saveModalPost}
        isOpen={!!saveModalPost}
        onClose={() => setSaveModalPost(null)}
        onSaveContext={handleSaveContext}
        onUnsave={handleUnsave}
      />

      {/* Post Options Modal */}
      <PostOptionsModal
        post={optionsModalPost}
        isOpen={!!optionsModalPost}
        onClose={() => setOptionsModalPost(null)}
      />

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onCreatePost={handleCreatePost}
        currentUser={CURRENT_USER}
      />

      {/* Instagram-style Toast Notification */}
      <Toast
        message={toast.message}
        actionText={toast.actionText}
        onAction={toast.onAction}
        isVisible={toast.isVisible}
      />

      {/* Subtle "2AM App Ideas" Corner Watermark */}
      <Watermark />
    </div>
  );
}
