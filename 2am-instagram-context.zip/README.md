# 2AM Ideas — #01
## Instagram × Save With Context

A prototype testing a single high-value interaction inside an Instagram-style interface: **attaching a quick, optional personal note to bookmarks so you remember why you saved them.**

---

### Features
* **Save With Context**: Tap the bookmark icon to save a post and optionally attach a reason/inspiration note.
* **Quick Inspiration Tags**: Fast chips (`💡 Design Inspo`, `🎨 Color Palette`, `🛠 Code to Try`, `📐 Layout Idea`, `📚 Reference`, `✨ Aesthetic`).
* **Centered Modal & Native Mobile Bottom Sheet**: Adaptive to desktop, tablet, and mobile screens.
* **Saved Collection Page**: Switch between Cards View (prominent context notes) and Grid View (3x3 photo grid with hover & click inspect modal).
* **Instagram Experience**: Stories carousel with modal story viewer, double-tap heart burst, comments preview, and inline comment posting.
* **Persistence**: Notes and bookmarks persist using `localStorage`.

---

### Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm run dev
   ```

3. Open **`http://localhost:5173/`** in your browser.

4. **Build for production:**
   ```bash
   npm run build
   ```
