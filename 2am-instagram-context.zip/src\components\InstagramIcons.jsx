import React from 'react';

// Exact Instagram SVG Wordmark
export function InstagramWordmark({ className = 'h-7 w-auto' }) {
  return (
    <svg
      viewBox="0 0 103 29"
      fill="currentColor"
      className={className}
      aria-label="Instagram"
    >
      <path d="M12.4 8.7c-.5 0-.9.1-1.3.4-.4.2-.7.6-.9 1.1-.2.5-.2 1.1-.1 1.7.1.6.4 1.1.8 1.5.4.4.9.7 1.5.8.6.1 1.2.1 1.7-.1.5-.2.9-.5 1.1-.9.2-.4.4-.8.4-1.3 0-1.8-1.4-3.2-3.2-3.2zm0 5c-.4 0-.7-.1-1-.3-.3-.2-.5-.5-.6-.8-.1-.3-.2-.7-.1-1 .1-.4.3-.7.5-.9.3-.3.6-.4.9-.5.4-.1.7 0 1 .1.3.1.6.3.8.6.2.3.3.6.3 1 0 1-.8 1.8-1.8 1.8zm11.7-5.5c-1.3 0-2.4.6-3.1 1.5V8.4h-2.3v13.5h2.4v-7.1c0-2.2 1.4-3.5 3-3.5 1.7 0 2.8 1.3 2.8 3.4v7.2h2.4v-7.6c-.1-2.9-2-4.7-5.2-4.7zm-9.3-5c0 .7.6 1.3 1.3 1.3.7 0 1.3-.6 1.3-1.3 0-.7-.6-1.3-1.3-1.3-.7 0-1.3.6-1.3 1.3zm.2 5.2h2.3v13.5h-2.3V8.4zm23.6-.2c-1.3 0-2.4.7-3 1.6V8.4h-2.3v18.5h2.4v-6.3c.7.8 1.7 1.4 2.9 1.4 2.9 0 5.4-2.4 5.4-6.8-.1-4.2-2.5-7-5.4-7zm-.6 11.7c-2 0-3.4-1.7-3.4-4.7 0-3.1 1.4-4.8 3.4-4.8s3.4 1.7 3.4 4.8c0 3-1.4 4.7-3.4 4.7zm13.1-11.5c-4.1 0-7.2 3.1-7.2 7 0 4.1 3.2 7 7.2 7s7.2-2.9 7.2-7c0-3.9-3.1-7-7.2-7zm0 11.7c-2.7 0-4.8-2.1-4.8-4.7 0-2.6 2.1-4.7 4.8-4.7s4.8 2.1 4.8 4.7c0 2.6-2.1 4.7-4.8 4.7zm11.2-11.7c-1.3 0-2.4.6-3.1 1.5V8.4h-2.3v13.5h2.4v-7.1c0-2.2 1.4-3.5 3-3.5 1.7 0 2.8 1.3 2.8 3.4v7.2h2.4v-7.6c0-2.9-2-4.7-5.2-4.7zm10.7 2.1h-2.4v9.6c0 1.2.6 1.8 1.8 1.8h.6v-1.9c-.3 0-.5 0-.5-.3v-9.2zm-.3-4c-.7 0-1.3.6-1.3 1.3 0 .7.6 1.3 1.3 1.3.7 0 1.3-.6 1.3-1.3 0-.7-.6-1.3-1.3-1.3zm12.3 8.3c-.6-.7-1.4-1.1-2.4-1.1-1.8 0-3.3 1.5-3.3 3.6 0 2 1.4 3.6 3.3 3.6 1 0 1.8-.4 2.4-1.1v.9c0 1.4-.9 2.2-2.2 2.2-1.1 0-1.8-.6-2.1-1.5l-2.1.9c.7 1.6 2.2 2.7 4.2 2.7 2.6 0 4.5-1.6 4.5-4.5V8.4h-2.3v1.8zm-2.2 4.9c-1 0-1.8-.9-1.8-2.2s.8-2.2 1.8-2.2 1.8.9 1.8 2.2-.8 2.2-1.8 2.2z" />
    </svg>
  );
}

export function HomeIcon({ active = false, size = 24 }) {
  if (active) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
        <path d="M22 22H14.5V14.5H9.5V22H2V9.5L12 2L22 9.5V22Z" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 2.5l9 7V21a1 1 0 0 1-1 1h-5.5v-7h-5v7H4a1 1 0 0 1-1-1V9.5z" />
    </svg>
  );
}

export function SearchIcon({ active = false, size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? "3" : "2"} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}

export function ExploreIcon({ active = false, size = 24 }) {
  if (active) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
        <circle cx="12" cy="12" r="10" />
        <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" fill="#fff" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
    </svg>
  );
}

export function ReelsIcon({ active = false, size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? "2.5" : "2"} strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 2v20" />
      <path d="M2 12h20" />
      <polygon points="9 8 13 10 9 12 9 8" fill={active ? "currentColor" : "none"} stroke="none" />
      <polygon points="9 14 13 16 9 18 9 14" fill={active ? "currentColor" : "none"} stroke="none" />
    </svg>
  );
}

export function MessagesIcon({ active = false, size = 24 }) {
  if (active) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.03 2 11c0 2.87 1.5 5.43 3.86 7.02l-.84 3.06a.75.75 0 0 0 .97.91l3.52-1.41C10.27 20.82 11.12 21 12 21c5.52 0 10-4.03 10-9s-4.48-9-10-9zm-1 12.5l-3-3 1.41-1.41 1.59 1.58 4.59-4.58 1.41 1.41-6 6z" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
    </svg>
  );
}

export function HeartIcon({ filled = false, size = 24, className = '' }) {
  if (filled) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="#ff3040" className={className}>
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

export function CreateIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="5" ry="5" />
      <line x1="12" y1="8" x2="12" y2="16" />
      <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  );
}

export function CommentIcon({ size = 24, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M20.656 17.008a9.993 9.993 0 1 0-3.59 3.615L22 22Z" fill="none" />
    </svg>
  );
}

export function ShareIcon({ size = 24, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" fill="none" />
    </svg>
  );
}

// Authentic Instagram Bookmark (Outline and Solid)
export function BookmarkIcon({ filled = false, size = 24, className = '' }) {
  if (filled) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M20 22a.999.999 0 0 1-.687-.273L12 14.815l-7.313 6.912A1 1 0 0 1 3 21V3a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1Z" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <polygon points="19 21 12 15 5 21 5 3 19 3 19 21" />
    </svg>
  );
}

export function MoreHorizontalIcon({ size = 24, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}>
      <circle cx="12" cy="12" r="1.75" />
      <circle cx="19.25" cy="12" r="1.75" />
      <circle cx="4.75" cy="12" r="1.75" />
    </svg>
  );
}

export function VerifiedBadge({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="#0095f6" className="inline-block flex-shrink-0">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.2 14.5l-4-4 1.41-1.41L10.8 13.67l6.79-6.79 1.41 1.41-8.2 8.21z" />
    </svg>
  );
}

export function SmileIcon({ size = 20, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" />
      <path d="M8 14s1.5 2 4 2 4-2 4-2" />
      <line x1="9" y1="9" x2="9.01" y2="9" />
      <line x1="15" y1="9" x2="15.01" y2="9" />
    </svg>
  );
}

export function CloseIcon({ size = 20, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}

export function NoteContextIcon({ size = 16, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </svg>
  );
}

export function GridIcon({ size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="7" />
      <rect x="14" y="3" width="7" height="7" />
      <rect x="14" y="14" width="7" height="7" />
      <rect x="3" y="14" width="7" height="7" />
    </svg>
  );
}

export function FeedListIcon({ size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="8" y1="6" x2="21" y2="6" />
      <line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" />
      <line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" />
      <line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}

export function MenuBarsIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  );
}
