import React from 'react';

export function PostOptionsModal({ post, isOpen, onClose }) {
  if (!isOpen || !post) return null;

  return (
    <div 
      className="ig-modal-backdrop animate-fade-in"
      onClick={onClose}
      style={{ zIndex: 110 }}
    >
      <div 
        className="animate-modal-desktop"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: '#ffffff',
          borderRadius: 12,
          width: '90%',
          maxWidth: 380,
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 8px 30px rgba(0,0,0,0.2)'
        }}
      >
        <button 
          onClick={() => { alert("Reported post"); onClose(); }}
          style={{
            padding: '14px 16px',
            fontSize: 14,
            fontWeight: 700,
            color: '#ed4956',
            borderBottom: '1px solid var(--ig-border-light)'
          }}
        >
          Report
        </button>

        <button 
          onClick={() => { alert(`Unfollowed @${post.username}`); onClose(); }}
          style={{
            padding: '14px 16px',
            fontSize: 14,
            fontWeight: 700,
            color: '#ed4956',
            borderBottom: '1px solid var(--ig-border-light)'
          }}
        >
          Unfollow
        </button>

        <button 
          onClick={() => { alert("Added to Favorites"); onClose(); }}
          style={{
            padding: '14px 16px',
            fontSize: 14,
            borderBottom: '1px solid var(--ig-border-light)'
          }}
        >
          Add to favorites
        </button>

        <button 
          onClick={() => {
            if (navigator.clipboard) {
              navigator.clipboard.writeText(window.location.href);
            }
            alert("Post link copied to clipboard!");
            onClose();
          }}
          style={{
            padding: '14px 16px',
            fontSize: 14,
            borderBottom: '1px solid var(--ig-border-light)'
          }}
        >
          Copy link
        </button>

        <button 
          onClick={onClose}
          style={{
            padding: '14px 16px',
            fontSize: 14,
            color: 'var(--ig-secondary-text)'
          }}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
