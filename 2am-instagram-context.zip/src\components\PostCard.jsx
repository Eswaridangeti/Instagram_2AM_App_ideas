import React, { useState, useRef } from 'react';
import {
  HeartIcon,
  CommentIcon,
  ShareIcon,
  BookmarkIcon,
  MoreHorizontalIcon,
  VerifiedBadge,
  SmileIcon,
  NoteContextIcon
} from './InstagramIcons';

export function PostCard({
  post,
  onToggleLike,
  onOpenSaveModal,
  onOpenOptions,
  onAddComment,
  currentUser
}) {
  const [commentText, setCommentText] = useState('');
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [isCaptionExpanded, setIsCaptionExpanded] = useState(false);
  const commentInputRef = useRef(null);
  const lastTapRef = useRef(0);

  // Handle double tap for mobile / double click for desktop
  const handleImageTap = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      triggerLikeWithBurst();
    }
    lastTapRef.current = now;
  };

  const triggerLikeWithBurst = () => {
    setShowHeartBurst(true);
    if (!post.isLiked) {
      onToggleLike(post.id);
    }
    setTimeout(() => {
      setShowHeartBurst(false);
    }, 900);
  };

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    onAddComment(post.id, commentText.trim());
    setCommentText('');
  };

  return (
    <article className="ig-post-card">
      {/* Post Header */}
      <div className="ig-post-header">
        <div className="ig-post-author">
          <img 
            src={post.avatar} 
            alt={post.username} 
            className="ig-post-avatar" 
            loading="lazy" 
          />
          <div className="ig-post-author-info">
            <div className="ig-post-username">
              <span>{post.username}</span>
              {post.isVerified && <VerifiedBadge size={13} />}
            </div>
            {post.location && (
              <span className="ig-post-location">{post.location}</span>
            )}
          </div>
        </div>

        <button 
          onClick={() => onOpenOptions(post)}
          style={{ padding: 6, color: 'var(--ig-primary-text)' }}
          title="More options"
        >
          <MoreHorizontalIcon size={18} />
        </button>
      </div>

      {/* Post Media with Double-tap Heart Burst */}
      <div 
        className="ig-post-image-wrap"
        onClick={handleImageTap}
        onDoubleClick={triggerLikeWithBurst}
      >
        <img 
          src={post.image} 
          alt={`Post by ${post.username}`} 
          className="ig-post-image"
          loading="lazy"
        />

        {showHeartBurst && (
          <div 
            className="animate-heart-burst"
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              pointerEvents: 'none',
              zIndex: 10,
              filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.4))'
            }}
          >
            <HeartIcon filled size={84} />
          </div>
        )}
      </div>

      {/* Post Action Buttons */}
      <div className="ig-post-actions">
        <div className="ig-post-actions-left">
          <button 
            className={`ig-action-btn ${post.isLiked ? 'animate-pop' : ''}`}
            onClick={() => onToggleLike(post.id)}
            title={post.isLiked ? 'Unlike' : 'Like'}
          >
            <HeartIcon filled={post.isLiked} size={25} />
          </button>

          <button 
            className="ig-action-btn"
            onClick={() => commentInputRef.current?.focus()}
            title="Comment"
          >
            <CommentIcon size={24} />
          </button>

          <button 
            className="ig-action-btn"
            onClick={() => {
              if (navigator.clipboard) {
                navigator.clipboard.writeText(window.location.href);
              }
              alert("Post link copied to clipboard!");
            }}
            title="Share Post"
          >
            <ShareIcon size={24} />
          </button>
        </div>

        {/* Save / Bookmark Button with Context Trigger */}
        <button 
          className={`ig-action-btn ${post.isSaved ? 'animate-pop' : ''}`}
          onClick={() => onOpenSaveModal(post)}
          title={post.isSaved ? "Saved (click to edit context or unsave)" : "Save post"}
          style={{ position: 'relative' }}
        >
          <BookmarkIcon filled={post.isSaved} size={25} />
        </button>
      </div>

      {/* Context Badge if Saved with Personal Note */}
      {post.isSaved && post.savedNote && (
        <div className="ig-post-context-badge">
          <NoteContextIcon size={16} className="text-blue-500 mt-0.5 flex-shrink-0" style={{ color: '#0095f6' }} />
          <div className="ig-post-context-text">
            <div className="ig-post-context-label">Your Saved Note</div>
            <div>“{post.savedNote}”</div>
          </div>
          <button 
            onClick={() => onOpenSaveModal(post)}
            style={{
              fontSize: 11,
              fontWeight: 600,
              color: '#0095f6',
              padding: '2px 6px',
              borderRadius: 4,
              backgroundColor: '#e0f1ff'
            }}
          >
            Edit
          </button>
        </div>
      )}

      {/* Post Details */}
      <div className="ig-post-details">
        {/* Like Count */}
        <div className="ig-post-likes">
          {(post.likesCount + (post.isLiked ? 1 : 0)).toLocaleString()} likes
        </div>

        {/* Caption */}
        <div className="ig-post-caption">
          <span className="ig-caption-author">{post.username}</span>
          <span>
            {isCaptionExpanded || post.caption.length <= 90
              ? post.caption
              : `${post.caption.slice(0, 90)}...`}
          </span>
          {post.caption.length > 90 && (
            <button 
              onClick={() => setIsCaptionExpanded(!isCaptionExpanded)}
              style={{
                color: 'var(--ig-secondary-text)',
                marginLeft: 4,
                fontSize: 14
              }}
            >
              {isCaptionExpanded ? 'less' : 'more'}
            </button>
          )}
        </div>

        {/* Comments Count Preview */}
        {post.commentsCount > 0 && (
          <div 
            className="ig-post-comments-count"
            onClick={() => commentInputRef.current?.focus()}
          >
            View all {post.commentsCount + (post.userComments ? post.userComments.length : 0)} comments
          </div>
        )}

        {/* Recent comments */}
        {post.recentComments && post.recentComments.slice(0, 2).map((c, i) => (
          <div key={i} style={{ fontSize: 13, lineHeight: '17px' }}>
            <span style={{ fontWeight: 600, marginRight: 6 }}>{c.username}</span>
            <span>{c.text}</span>
          </div>
        ))}

        {/* User-added comments */}
        {post.userComments && post.userComments.map((c, i) => (
          <div key={`uc-${i}`} style={{ fontSize: 13, lineHeight: '17px' }}>
            <span style={{ fontWeight: 600, marginRight: 6 }}>{currentUser.username}</span>
            <span>{c}</span>
          </div>
        ))}

        {/* Timestamp */}
        <div className="ig-post-timestamp">
          {post.timestamp}
        </div>
      </div>

      {/* Add a Comment Input Bar */}
      <form onSubmit={handleCommentSubmit} className="ig-post-comment-input-row">
        <SmileIcon size={20} className="text-gray-400" style={{ color: 'var(--ig-secondary-text)' }} />
        <input 
          ref={commentInputRef}
          type="text" 
          className="ig-comment-input" 
          placeholder="Add a comment..."
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
        />
        <button 
          type="submit" 
          className="ig-comment-post-btn"
          disabled={!commentText.trim()}
        >
          Post
        </button>
      </form>
    </article>
  );
}
