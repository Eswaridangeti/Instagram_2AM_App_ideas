import React from 'react';
import { MessagesIcon, HeartIcon, BookmarkIcon } from './InstagramIcons';

export function MobileHeader({ currentView, setCurrentView, savedCount }) {
  return (
    <header className="ig-mobile-header">
      <div 
        onClick={() => setCurrentView('feed')} 
        style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
      >
        <span className="ig-logo-script" style={{ fontSize: 26 }}>2AM Ideas</span>
        <span 
          style={{
            fontSize: 10,
            fontWeight: 700,
            color: '#0095f6',
            background: '#e0f1ff',
            padding: '2px 5px',
            borderRadius: 4,
            letterSpacing: '0.3px'
          }}
        >
          #01
        </span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <button 
          onClick={() => setCurrentView('saved')}
          title="Saved Posts"
          style={{ position: 'relative', display: 'flex', alignItems: 'center', padding: 4 }}
        >
          <BookmarkIcon filled={currentView === 'saved'} size={24} />
          {savedCount > 0 && (
            <span 
              style={{
                position: 'absolute',
                top: 0,
                right: 0,
                background: '#0095f6',
                color: '#fff',
                fontSize: 10,
                fontWeight: 700,
                width: 15,
                height: 15,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              {savedCount}
            </span>
          )}
        </button>

        <button onClick={() => alert("Notifications mockup")} style={{ display: 'flex', alignItems: 'center', padding: 4 }}>
          <HeartIcon size={24} />
        </button>

        <button onClick={() => alert("Direct Messages mockup")} style={{ display: 'flex', alignItems: 'center', position: 'relative', padding: 4 }}>
          <MessagesIcon size={24} />
          <span 
            style={{
              position: 'absolute',
              top: 0,
              right: 0,
              background: '#ff3040',
              color: '#fff',
              fontSize: 10,
              fontWeight: 700,
              width: 13,
              height: 13,
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            2
          </span>
        </button>
      </div>
    </header>
  );
}
