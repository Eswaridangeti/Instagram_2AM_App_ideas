import React from 'react';
import { HomeIcon, SearchIcon, CreateIcon, BookmarkIcon } from './InstagramIcons';

export function MobileBottomNav({ currentView, setCurrentView, currentUser, onOpenCreate, savedCount }) {
  return (
    <nav className="ig-mobile-bottom-nav">
      <button 
        onClick={() => setCurrentView('feed')} 
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <HomeIcon active={currentView === 'feed'} size={25} />
      </button>

      <button 
        onClick={() => alert("Search mockup")} 
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <SearchIcon size={24} />
      </button>

      <button 
        onClick={onOpenCreate} 
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <CreateIcon size={25} />
      </button>

      <button 
        onClick={() => setCurrentView('saved')} 
        style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <BookmarkIcon filled={currentView === 'saved'} size={24} />
        {savedCount > 0 && (
          <span 
            style={{
              position: 'absolute',
              top: -3,
              right: -5,
              background: '#0095f6',
              color: '#fff',
              fontSize: 10,
              fontWeight: 700,
              width: 15,
              height: 15,
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            {savedCount}
          </span>
        )}
      </button>

      <button 
        onClick={() => setCurrentView('saved')} 
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <img 
          src={currentUser.avatar} 
          alt={currentUser.username} 
          style={{
            width: 25,
            height: 25,
            borderRadius: '50%',
            objectFit: 'cover',
            border: currentView === 'saved' ? '2px solid #262626' : '1px solid #dbdbdb'
          }} 
        />
      </button>
    </nav>
  );
}
