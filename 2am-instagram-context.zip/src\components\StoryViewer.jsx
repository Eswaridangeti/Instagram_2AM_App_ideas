import React, { useState, useEffect } from 'react';
import { CloseIcon, HeartIcon } from './InstagramIcons';

export function StoryViewer({ story, allStories, onClose, onSelectStory }) {
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);
  const [replyText, setReplyText] = useState('');

  const currentIndex = allStories.findIndex(s => s.id === story.id);

  const handleNext = () => {
    if (currentIndex < allStories.length - 1) {
      onSelectStory(allStories[currentIndex + 1]);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      onSelectStory(allStories[currentIndex - 1]);
      setProgress(0);
    }
  };

  useEffect(() => {
    setProgress(0);
    setHasLiked(false);
  }, [story.id]);

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNext();
          return 0;
        }
        return prev + 1.5;
      });
    }, 60);

    return () => clearInterval(interval);
  }, [isPaused, story.id, currentIndex]);

  return (
    <div 
      className="ig-modal-backdrop animate-fade-in"
      style={{ zIndex: 200, background: 'rgba(18, 18, 18, 0.95)' }}
    >
      {/* Top right close button */}
      <button 
        onClick={onClose}
        style={{
          position: 'absolute',
          top: 20,
          right: 24,
          color: '#ffffff',
          zIndex: 210,
          opacity: 0.9
        }}
      >
        <CloseIcon size={28} />
      </button>

      {/* Story phone frame */}
      <div 
        style={{
          position: 'relative',
          width: '100%',
          maxWidth: 420,
          height: '88vh',
          maxHeight: 740,
          borderRadius: 16,
          overflow: 'hidden',
          backgroundColor: '#000000',
          boxShadow: '0 20px 50px rgba(0,0,0,0.6)',
          display: 'flex',
          flexDirection: 'column'
        }}
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Progress bars */}
        <div 
          style={{
            position: 'absolute',
            top: 12,
            left: 12,
            right: 12,
            zIndex: 30,
            display: 'flex',
            gap: 4
          }}
        >
          {allStories.map((s, idx) => (
            <div 
              key={s.id}
              style={{
                flex: 1,
                height: 2.5,
                borderRadius: 2,
                backgroundColor: 'rgba(255, 255, 255, 0.35)',
                overflow: 'hidden'
              }}
            >
              <div 
                style={{
                  height: '100%',
                  backgroundColor: '#ffffff',
                  width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%',
                  transition: idx === currentIndex ? 'width 0.06s linear' : 'none'
                }}
              />
            </div>
          ))}
        </div>

        {/* Story author header */}
        <div 
          style={{
            position: 'absolute',
            top: 24,
            left: 14,
            right: 14,
            zIndex: 30,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            color: '#ffffff'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img 
              src={story.avatar} 
              alt={story.username} 
              style={{ width: 34, height: 34, borderRadius: '50%', border: '1.5px solid #ffffff' }} 
            />
            <span style={{ fontWeight: 600, fontSize: 13, textShadow: '0 1px 3px rgba(0,0,0,0.7)' }}>
              {story.username}
            </span>
            <span style={{ fontSize: 12, opacity: 0.75 }}>3h</span>
          </div>

          <div style={{ fontSize: 10, background: 'rgba(0,0,0,0.5)', padding: '2px 8px', borderRadius: 12, color: 'rgba(255,255,255,0.8)' }}>
            2AM App Ideas
          </div>
        </div>

        {/* Navigation tap targets */}
        <div 
          onClick={(e) => { e.stopPropagation(); handlePrev(); }}
          style={{ position: 'absolute', top: 60, bottom: 80, left: 0, width: '35%', zIndex: 25, cursor: 'pointer' }}
        />
        <div 
          onClick={(e) => { e.stopPropagation(); handleNext(); }}
          style={{ position: 'absolute', top: 60, bottom: 80, right: 0, width: '65%', zIndex: 25, cursor: 'pointer' }}
        />

        {/* Story media */}
        <div style={{ width: '100%', height: '100%', position: 'relative' }}>
          <img 
            src={story.storyImage} 
            alt="Story" 
            style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
          />
          <div 
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, transparent 20%, transparent 75%, rgba(0,0,0,0.6) 100%)',
              pointerEvents: 'none'
            }}
          />
        </div>

        {/* Caption */}
        {story.caption && (
          <div 
            style={{
              position: 'absolute',
              bottom: 74,
              left: 16,
              right: 16,
              zIndex: 30,
              color: '#ffffff',
              fontSize: 14,
              textShadow: '0 1px 4px rgba(0,0,0,0.8)',
              background: 'rgba(0,0,0,0.3)',
              padding: '8px 12px',
              borderRadius: 8,
              backdropFilter: 'blur(4px)'
            }}
          >
            {story.caption}
          </div>
        )}

        {/* Story bottom interaction bar */}
        <div 
          style={{
            position: 'absolute',
            bottom: 14,
            left: 14,
            right: 14,
            zIndex: 30,
            display: 'flex',
            alignItems: 'center',
            gap: 12
          }}
        >
          <div 
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              background: 'transparent',
              border: '1px solid rgba(255, 255, 255, 0.45)',
              borderRadius: 24,
              padding: '8px 16px'
            }}
          >
            <input 
              type="text" 
              placeholder={`Reply to ${story.username}...`}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && replyText.trim()) {
                  alert(`Sent reply to ${story.username}: "${replyText}"`);
                  setReplyText('');
                }
              }}
              style={{
                width: '100%',
                background: 'transparent',
                border: 'none',
                outline: 'none',
                color: '#ffffff',
                fontSize: 13
              }}
            />
          </div>

          <button 
            onClick={() => setHasLiked(!hasLiked)}
            style={{
              color: hasLiked ? '#ff3040' : '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 4
            }}
          >
            <HeartIcon filled={hasLiked} size={26} />
          </button>
        </div>
      </div>
    </div>
  );
}
