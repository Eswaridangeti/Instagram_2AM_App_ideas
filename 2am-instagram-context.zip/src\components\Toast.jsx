import React from 'react';
import { BookmarkIcon } from './InstagramIcons';

export function Toast({ message, actionText, onAction, isVisible }) {
  if (!isVisible) return null;

  return (
    <div className="ig-toast animate-toast">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <BookmarkIcon filled size={18} />
        <span>{message}</span>
      </div>
      {actionText && (
        <button 
          onClick={onAction} 
          className="ig-toast-action"
        >
          {actionText}
        </button>
      )}
    </div>
  );
}
