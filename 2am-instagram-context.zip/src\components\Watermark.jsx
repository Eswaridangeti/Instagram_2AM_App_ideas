import React, { useState } from 'react';

export function Watermark() {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <div style={{ position: 'fixed', bottom: 16, right: 16, zIndex: 60 }}>
      {showInfo && (
        <div 
          className="animate-modal-desktop"
          style={{
            position: 'absolute',
            bottom: 40,
            right: 0,
            width: 290,
            background: 'rgba(255, 255, 255, 0.98)',
            backdropFilter: 'blur(16px)',
            border: '1px solid rgba(0, 0, 0, 0.1)',
            borderRadius: 12,
            padding: 14,
            boxShadow: '0 10px 30px rgba(0, 0, 0, 0.12)',
            fontSize: 12,
            color: '#333333',
            lineHeight: '17px'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontWeight: 700, fontSize: 13, color: '#111827' }}>2AM App Ideas</span>
            <span style={{ fontSize: 10, background: '#f3f4f6', padding: '2px 6px', borderRadius: 4, fontWeight: 600 }}>#01</span>
          </div>
          <p style={{ color: '#4b5563', marginBottom: 8 }}>
            <strong>Instagram × Save With Context</strong>
          </p>
          <p style={{ color: '#6b7280', fontSize: 11, marginBottom: 10 }}>
            Solve bookmark amnesia: attach a quick, optional note when saving any post to remember exactly why it inspired you.
          </p>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button 
              onClick={() => setShowInfo(false)}
              style={{ fontSize: 11, fontWeight: 600, color: '#0095f6' }}
            >
              Close
            </button>
          </div>
        </div>
      )}

      <button 
        className="watermark-pill"
        onClick={() => setShowInfo(!showInfo)}
        title="2AM App Ideas Project Info"
        aria-label="2AM App Ideas Watermark"
      >
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981' }} />
        <span style={{ fontWeight: 600 }}>2AM App Ideas</span>
        <span className="watermark-badge">#01</span>
      </button>
    </div>
  );
}
