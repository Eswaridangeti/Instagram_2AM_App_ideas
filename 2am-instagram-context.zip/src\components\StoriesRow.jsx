import React from 'react';

export function StoriesRow({ stories, onSelectStory }) {
  return (
    <div className="ig-stories-container no-scrollbar">
      {stories.map((story) => (
        <div 
          key={story.id} 
          className="ig-story-item"
          onClick={() => onSelectStory(story)}
        >
          <div className={`ig-story-avatar-wrap ${story.hasUnseen ? 'story-ring-gradient' : 'story-ring-seen'}`}>
            <div className="ig-story-avatar-inner">
              <img src={story.avatar} alt={story.username} loading="lazy" />
              {story.isUser && (
                <div 
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    right: 0,
                    background: '#0095f6',
                    color: '#ffffff',
                    width: 18,
                    height: 18,
                    borderRadius: '50%',
                    border: '2px solid #ffffff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 14,
                    fontWeight: 700,
                    lineHeight: 1
                  }}
                >
                  +
                </div>
              )}
            </div>
          </div>
          <span className="ig-story-username">{story.username}</span>
        </div>
      ))}
    </div>
  );
}
