export const CURRENT_USER = {
  username: 'alex.creates',
  fullName: 'Alex Rivera',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  bio: 'Design engineer & late night builder 🌙 2AM App Ideas tester',
  savedCount: 1
};

export const MOCK_STORIES = [
  {
    id: 's0',
    username: 'Your story',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    isUser: true,
    hasUnseen: false,
    storyImage: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1080&q=80',
    caption: 'Late night prototyping session 💻 #2AMAppIdeas'
  },
  {
    id: 's1',
    username: 'daily.designs',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1080&q=80',
    caption: 'Experimenting with tactile micro-interactions today'
  },
  {
    id: 's2',
    username: 'pixeljournal',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=1080&q=80',
    caption: 'Tokyo typography archive issue #4 printed!'
  },
  {
    id: 's3',
    username: 'codeandcoffee',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1080&q=80',
    caption: 'New custom split mechanical keyboard build completed'
  },
  {
    id: 's4',
    username: 'minimalspaces',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1080&q=80',
    caption: 'Morning sun hitting raw board-formed concrete'
  },
  {
    id: 's5',
    username: 'framebyframe',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1080&q=80',
    caption: '35mm grain from Shinjuku backstreets at 1 AM'
  },
  {
    id: 's6',
    username: 'foodnotes',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=1080&q=80',
    caption: 'Fresh wild blackberry galette out of the wood oven'
  },
  {
    id: 's7',
    username: 'wanderlust.frames',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    isUser: false,
    hasUnseen: true,
    storyImage: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1080&q=80',
    caption: 'First light over Tre Cime di Lavaredo'
  }
];

export const MOCK_POSTS = [
  {
    id: 'post-1',
    username: 'daily.designs',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    isVerified: true,
    location: 'Design Systems Studio, SF',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Exploring fluid volumetric glass materials and subtle refraction for our next mobile design system iteration. Clean spacing with 1px border highlights makes all the difference.',
    likesCount: 2842,
    timestamp: '2 HOURS AGO',
    initialSaved: true,
    initialNote: 'Love this glass refraction UI — want to try something similar for my portfolio header.',
    commentsCount: 94,
    recentComments: [
      { username: 'ui_vector', text: 'The light refractions on that card edge are sublime ✨' },
      { username: 'sam_kodak', text: 'What tool are you rendering these shaders with?' }
    ]
  },
  {
    id: 'post-2',
    username: 'codeandcoffee',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    isVerified: false,
    location: 'Kyoto, Japan',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Rainy afternoon desk setup. 40% ortholinear mechanical keyboard, OLED ambient lamp, and clean neovim dark theme. The quieter the setup, the deeper the focus.',
    likesCount: 5120,
    timestamp: '4 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 168,
    recentComments: [
      { username: 'dev_milo', text: 'Which keycaps are those? So clean!' },
      { username: 'techminimalist', text: 'The lamp lighting temperature is perfect' }
    ]
  },
  {
    id: 'post-3',
    username: 'minimalspaces',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=150&q=80',
    isVerified: true,
    location: 'Copenhagen, Denmark',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Raw cedar timber paired with cast-in-place concrete. Natural overhead skylights illuminate the atrium without artificial ambient lighting.',
    likesCount: 3914,
    timestamp: '7 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 62,
    recentComments: [
      { username: 'arch.daily', text: 'Tadao Ando influence is so well executed here.' }
    ]
  },
  {
    id: 'post-4',
    username: 'framebyframe',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=150&q=80',
    isVerified: false,
    location: 'Shinjuku, Tokyo',
    image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Neon reflections on rain-slick asphalt at 2 AM. Shot on Cinestill 800T through an old 50mm f/1.2 lens. No color grading applied, pure tungsten halation.',
    likesCount: 8931,
    timestamp: '9 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 245,
    recentComments: [
      { username: 'analog.vibes', text: 'That red halation around the neon signage is iconic 800T' },
      { username: 'cinemaniac', text: 'Blade Runner mood captured effortlessly' }
    ]
  },
  {
    id: 'post-5',
    username: 'foodnotes',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    isVerified: true,
    location: 'Osteria Botanica, Bologna',
    image: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Handcrafted ricotta gnocchi with brown butter, crispy sage, and shaved summer truffles. Plated on hand-spun ceramic stoneware.',
    likesCount: 4180,
    timestamp: '12 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 88,
    recentComments: [
      { username: 'chef_elena', text: 'The gloss on that brown butter sauce is perfection' }
    ]
  },
  {
    id: 'post-6',
    username: 'pixeljournal',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    isVerified: true,
    location: 'Zurich Design Museum',
    image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Swiss international typographic style poster archive from 1968. Asymmetric grid systems, single typeface hierarchy, and deliberate white space.',
    likesCount: 6732,
    timestamp: '14 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 112,
    recentComments: [
      { username: 'type_foundry', text: 'Timeless layout. Still beats 99% of modern web designs.' }
    ]
  },
  {
    id: 'post-7',
    username: 'wanderlust.frames',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    isVerified: false,
    location: 'Val di Funes, South Tyrol',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Sunrise hitting the sheer limestone cliffs above the church of St. Maddalena. Crisp alpine morning air at -2°C.',
    likesCount: 9410,
    timestamp: '18 HOURS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 310,
    recentComments: [
      { username: 'earth_travels', text: 'One of the most photogenic valleys in the world 🏔️' }
    ]
  },
  {
    id: 'post-8',
    username: 'brewandbean',
    avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=150&q=80',
    isVerified: false,
    location: 'Single Origin Lab, Melbourne',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Morning pour-over ritual with Ethiopian anaerobic natural processed beans. Floral jasmine aromatics, bergamot notes, and a honey-sweet finish.',
    likesCount: 2240,
    timestamp: '1 DAY AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 47,
    recentComments: [
      { username: 'coffeeculture', text: 'Anaerobic naturals from Yirgacheffe hit different 👌' }
    ]
  },
  {
    id: 'post-9',
    username: 'studio.forma',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    isVerified: true,
    location: 'Barcelona, Spain',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Wheel-thrown terracotta amphoras drying slowly in the shade before first bisque firing. Preserving Mediterranean ceramic heritage with raw organic curves.',
    likesCount: 3120,
    timestamp: '1 DAY AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 54,
    recentComments: [
      { username: 'clay_craft', text: 'The natural earthy textures are stunning' }
    ]
  },
  {
    id: 'post-10',
    username: 'layers.archive',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=150&q=80',
    isVerified: false,
    location: 'Berlin Mitte',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1080&q=80',
    aspectRatio: 'aspect-square',
    caption: 'Monochrome tailoring study. Heavy Japanese wool twill trench layered over washed raw silk. Utilitarian pocket detailing without extraneous adornment.',
    likesCount: 4780,
    timestamp: '2 DAYS AGO',
    initialSaved: false,
    initialNote: '',
    commentsCount: 93,
    recentComments: [
      { username: 'fashion_notes', text: 'The drape and silhouette on that wool coat are immaculate.' }
    ]
  }
];

export const SUGGESTED_USERS = [
  {
    username: 'designmilk',
    name: 'Design Milk',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    relation: 'Followed by minimalspaces + 4 more'
  },
  {
    username: 'archdigest',
    name: 'Architectural Digest',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80',
    relation: 'Suggested for you'
  },
  {
    username: 'linear.app',
    name: 'Linear',
    avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&w=150&q=80',
    relation: 'Followed by daily.designs'
  },
  {
    username: 'kinfolk',
    name: 'Kinfolk Magazine',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80',
    relation: 'Suggested for you'
  },
  {
    username: 'monoclemag',
    name: 'Monocle',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80',
    relation: 'Followed by codeandcoffee + 2 more'
  }
];
