import React, { useState } from 'react';
import { 
  BookmarkIcon, 
  GridIcon, 
  FeedListIcon, 
  NoteContextIcon, 
  CloseIcon,
  HeartIcon
} from './InstagramIcons';

export function SavedPage({ 
  savedPosts, 
  onBackToFeed, 
  onOpenSaveModal, 
  onUnsavePost 
}) {
  const [viewMode, setViewMode] = useState('cards'); // 'cards' | 'grid'
  const [filterMode, setFilterMode] = useState('all'); // 'all' | 'with-notes'
  const [activeInspectionPost, setActiveInspectionPost] = useState(null);

  const postsWithNotes = savedPosts.filter(p => p.savedNote && p.savedNote.trim().length > 0);
  const displayPosts = filterMode === 'with-notes' ? postsWithNotes : savedPosts;

  return (
    <div style={{ maxWidth: 640, width: '100%', margin: '0 auto', padding: '0 16px 60px 16px' }}>
      {/* Top Header */}
      <div 
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '16px 0 20px 0',
          borderBottom: '1px solid var(--ig-border-light)',
          marginBottom: 20
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button 
            onClick={onBackToFeed}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 36,
              height: 36,
              borderRadius: '50%',
              backgroundColor: 'var(--ig-hover-bg)',
              transition: 'background-color 0.15s ease'
            }}
            title="Back to feed"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>

          <div>
            <h1 style={{ fontSize: 20, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span>Saved</span>
              <span 
                style={{
                  fontSize: 12,
                  fontWeight: 600,
                  backgroundColor: 'var(--ig-hover-bg)',
                  padding: '2px 8px',
                  borderRadius: 12,
                  color: 'var(--ig-secondary-text)'
                }}
              >
                {savedPosts.length}
              </span>
            </h1>
            <p style={{ fontSize: 12, color: 'var(--ig-secondary-text)', marginTop: 2 }}>
              Only you can see what you've saved
            </p>
          </div>
        </div>

        {/* View Mode Toggle & Subtle Watermark */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div 
            style={{
              display: 'flex',
              background: 'var(--ig-hover-bg)',
              padding: 2,
              borderRadius: 6
            }}
          >
            <button
              onClick={() => setViewMode('cards')}
              style={{
                padding: '6px 10px',
                borderRadius: 4,
                backgroundColor: viewMode === 'cards' ? '#ffffff' : 'transparent',
                boxShadow: viewMode === 'cards' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                fontSize: 12,
                fontWeight: 600,
                color: viewMode === 'cards' ? 'var(--ig-primary-text)' : 'var(--ig-secondary-text)'
              }}
              title="Cards View with Context"
            >
              <FeedListIcon size={16} />
              <span>Cards</span>
            </button>

            <button
              onClick={() => setViewMode('grid')}
              style={{
                padding: '6px 10px',
                borderRadius: 4,
                backgroundColor: viewMode === 'grid' ? '#ffffff' : 'transparent',
                boxShadow: viewMode === 'grid' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                fontSize: 12,
                fontWeight: 600,
                color: viewMode === 'grid' ? 'var(--ig-primary-text)' : 'var(--ig-secondary-text)'
              }}
              title="Grid View"
            >
              <GridIcon size={16} />
              <span>Grid</span>
            </button>
          </div>

          <span 
            className="watermark-subtle" 
            style={{ display: 'inline-flex', fontSize: 11, color: '#8e8e8e' }}
          >
            2AM Ideas
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div 
        style={{
          display: 'flex',
          gap: 10,
          marginBottom: 24,
          alignItems: 'center'
        }}
      >
        <button
          onClick={() => setFilterMode('all')}
          style={{
            padding: '6px 14px',
            borderRadius: 18,
            fontSize: 13,
            fontWeight: 600,
            backgroundColor: filterMode === 'all' ? '#262626' : 'var(--ig-hover-bg)',
            color: filterMode === 'all' ? '#ffffff' : 'var(--ig-primary-text)',
            transition: 'all 0.15s ease'
          }}
        >
          All Posts ({savedPosts.length})
        </button>

        <button
          onClick={() => setFilterMode('with-notes')}
          style={{
            padding: '6px 14px',
            borderRadius: 18,
            fontSize: 13,
            fontWeight: 600,
            backgroundColor: filterMode === 'with-notes' ? 'var(--ig-blue)' : 'var(--ig-hover-bg)',
            color: filterMode === 'with-notes' ? '#ffffff' : 'var(--ig-primary-text)',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            transition: 'all 0.15s ease'
          }}
        >
          <NoteContextIcon size={14} />
          <span>With Context Notes ({postsWithNotes.length})</span>
        </button>
      </div>

      {/* Empty State */}
      {displayPosts.length === 0 && (
        <div 
          style={{
            padding: '60px 20px',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 14
          }}
        >
          <div 
            style={{
              width: 64,
              height: 64,
              borderRadius: '50%',
              border: '2px solid #262626',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <BookmarkIcon size={32} />
          </div>
          <h2 style={{ fontSize: 18, fontWeight: 700 }}>
            {filterMode === 'with-notes' ? 'No posts saved with context notes yet' : 'No saved posts yet'}
          </h2>
          <p style={{ fontSize: 14, color: 'var(--ig-secondary-text)', maxWidth: 360 }}>
            {filterMode === 'with-notes'
              ? 'Tap the bookmark icon on any post in the feed and add an optional note to capture your inspiration.'
              : 'Save photos and videos that you want to see again. Attach a short note explaining why you saved it!'}
          </p>
          <button 
            onClick={onBackToFeed}
            className="ig-btn-primary"
            style={{ marginTop: 8 }}
          >
            Explore Home Feed
          </button>
        </div>
      )}

      {/* CARDS VIEW MODE */}
      {viewMode === 'cards' && displayPosts.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 470, width: '100%', margin: '0 auto' }}>
          {displayPosts.map((post) => (
            <div 
              key={post.id}
              style={{
                background: '#ffffff',
                border: '1px solid var(--ig-border)',
                borderRadius: 10,
                overflow: 'hidden',
                boxShadow: '0 2px 8px rgba(0,0,0,0.03)'
              }}
            >
              {/* Creator header */}
              <div 
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '12px 14px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <img 
                    src={post.avatar} 
                    alt={post.username} 
                    style={{ width: 34, height: 34, borderRadius: '50%', objectFit: 'cover' }} 
                  />
                  <div>
                    <span style={{ fontWeight: 600, fontSize: 14 }}>@{post.username}</span>
                    {post.location && (
                      <div style={{ fontSize: 11, color: 'var(--ig-secondary-text)' }}>{post.location}</div>
                    )}
                  </div>
                </div>

                <button 
                  onClick={() => onUnsavePost(post.id)}
                  style={{
                    color: '#8e8e8e',
                    fontSize: 12,
                    padding: '4px 8px',
                    borderRadius: 4
                  }}
                  title="Remove from saved"
                >
                  <BookmarkIcon filled size={20} />
                </button>
              </div>

              {/* Post image */}
              <div style={{ width: '100%', background: '#000', maxHeight: 480, overflow: 'hidden' }}>
                <img 
                  src={post.image} 
                  alt={post.caption} 
                  style={{ width: '100%', height: 'auto', display: 'block', objectFit: 'cover' }} 
                />
              </div>

              {/* CONTEXT NOTE BOX (Core Feature) */}
              <div 
                style={{
                  padding: '14px',
                  background: post.savedNote ? '#f8fafc' : '#ffffff',
                  borderTop: '1px solid var(--ig-border-light)',
                  borderBottom: '1px solid var(--ig-border-light)'
                }}
              >
                {post.savedNote ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span 
                        style={{
                          fontSize: 11,
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: 0.5,
                          color: '#0095f6',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4
                        }}
                      >
                        <NoteContextIcon size={13} />
                        Personal Context Note
                      </span>

                      <button 
                        onClick={() => onOpenSaveModal(post)}
                        style={{
                          fontSize: 12,
                          fontWeight: 600,
                          color: '#0095f6'
                        }}
                      >
                        Edit Note
                      </button>
                    </div>

                    <div 
                      style={{
                        fontSize: 14,
                        lineHeight: '20px',
                        color: '#1e293b',
                        fontStyle: 'italic',
                        background: '#ffffff',
                        padding: '10px 14px',
                        borderRadius: 6,
                        border: '1px solid #e2e8f0',
                        borderLeft: '3px solid #0095f6'
                      }}
                    >
                      “{post.savedNote}”
                    </div>
                  </div>
                ) : (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 13, color: 'var(--ig-secondary-text)' }}>
                      No personal note added yet.
                    </span>
                    <button 
                      onClick={() => onOpenSaveModal(post)}
                      style={{
                        fontSize: 12,
                        fontWeight: 600,
                        color: '#0095f6',
                        background: '#e0f1ff',
                        padding: '4px 10px',
                        borderRadius: 6
                      }}
                    >
                      + Add Note
                    </button>
                  </div>
                )}
              </div>

              {/* Caption snippet & actions */}
              <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div style={{ fontSize: 13, lineHeight: '18px' }}>
                  <span style={{ fontWeight: 600, marginRight: 6 }}>{post.username}</span>
                  <span style={{ color: '#4a4a4a' }}>{post.caption}</span>
                </div>

                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginTop: 4,
                    paddingTop: 8,
                    borderTop: '1px solid var(--ig-border-light)'
                  }}
                >
                  <span style={{ fontSize: 11, color: 'var(--ig-secondary-text)' }}>{post.timestamp}</span>
                  <button 
                    onClick={() => onUnsavePost(post.id)}
                    style={{ fontSize: 12, color: '#ed4956', fontWeight: 500 }}
                  >
                    Remove from Saved
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* GRID VIEW MODE */}
      {viewMode === 'grid' && displayPosts.length > 0 && (
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 12
          }}
        >
          {displayPosts.map((post) => (
            <div 
              key={post.id}
              onClick={() => setActiveInspectionPost(post)}
              style={{
                position: 'relative',
                aspectRatio: '1 / 1',
                borderRadius: 6,
                overflow: 'hidden',
                cursor: 'pointer',
                backgroundColor: '#f2f2f2'
              }}
            >
              <img 
                src={post.image} 
                alt={post.caption} 
                style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
              />

              {/* If post has note, show small badge */}
              {post.savedNote && (
                <div 
                  style={{
                    position: 'absolute',
                    top: 8,
                    right: 8,
                    background: 'rgba(0, 149, 246, 0.92)',
                    color: '#ffffff',
                    padding: '3px 6px',
                    borderRadius: 12,
                    fontSize: 10,
                    fontWeight: 700,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 3,
                    boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
                  }}
                >
                  <NoteContextIcon size={11} />
                  <span>Note</span>
                </div>
              )}

              {/* Creator watermark on tile bottom */}
              <div 
                style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  background: 'linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.65) 100%)',
                  padding: '16px 8px 6px 8px',
                  color: '#ffffff',
                  fontSize: 11,
                  fontWeight: 600,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}
              >
                @{post.username}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Inspection Modal for Grid view click */}
      {activeInspectionPost && (
        <div 
          className="ig-modal-backdrop animate-fade-in"
          onClick={() => setActiveInspectionPost(null)}
          style={{ zIndex: 120 }}
        >
          <div 
            className="ig-modal-container animate-modal-desktop"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: 540 }}
          >
            <div className="ig-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <img 
                  src={activeInspectionPost.avatar} 
                  alt="" 
                  style={{ width: 28, height: 28, borderRadius: '50%' }} 
                />
                <span style={{ fontWeight: 600 }}>@{activeInspectionPost.username}</span>
              </div>
              <button onClick={() => setActiveInspectionPost(null)}>
                <CloseIcon size={20} />
              </button>
            </div>

            <div style={{ maxHeight: 380, overflow: 'hidden', background: '#000' }}>
              <img 
                src={activeInspectionPost.image} 
                alt="" 
                style={{ width: '100%', height: 'auto', maxHeight: 380, objectFit: 'contain' }} 
              />
            </div>

            <div className="ig-modal-body">
              {activeInspectionPost.savedNote ? (
                <div 
                  style={{
                    background: '#f8fafc',
                    padding: '12px 14px',
                    borderRadius: 8,
                    borderLeft: '3px solid #0095f6'
                  }}
                >
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#0095f6', marginBottom: 4 }}>
                    YOUR SAVED CONTEXT
                  </div>
                  <div style={{ fontSize: 14, color: '#1e293b' }}>
                    “{activeInspectionPost.savedNote}”
                  </div>
                </div>
              ) : (
                <div style={{ fontSize: 13, color: 'var(--ig-secondary-text)' }}>
                  No note attached yet.
                </div>
              )}

              <p style={{ fontSize: 13, color: '#4a4a4a', lineHeight: '18px' }}>
                <span style={{ fontWeight: 600, marginRight: 6 }}>{activeInspectionPost.username}</span>
                {activeInspectionPost.caption}
              </p>
            </div>

            <div className="ig-modal-footer">
              <button 
                className="ig-btn-secondary"
                onClick={() => {
                  onUnsavePost(activeInspectionPost.id);
                  setActiveInspectionPost(null);
                }}
                style={{ color: '#ed4956' }}
              >
                Remove from Saved
              </button>
              <button 
                className="ig-btn-primary"
                onClick={() => {
                  const postToEdit = activeInspectionPost;
                  setActiveInspectionPost(null);
                  onOpenSaveModal(postToEdit);
                }}
              >
                {activeInspectionPost.savedNote ? 'Edit Note' : 'Add Note'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tasteful Footer Watermark */}
      <footer 
        style={{
          marginTop: 48,
          paddingTop: 20,
          borderTop: '1px solid var(--ig-border-light)',
          textAlign: 'center',
          color: '#a8a8a8',
          fontSize: 12
        }}
      >
        <span style={{ fontWeight: 600 }}>2AM App Ideas</span> — #01 Instagram × Save With Context
      </footer>
    </div>
  );
}
