import React, { useState } from 'react';
import { SUGGESTED_USERS } from '../data/mockData';

export function RightSidebar({ currentUser, onOpenProfile }) {
  const [followingMap, setFollowingMap] = useState({});

  const toggleFollow = (username) => {
    setFollowingMap((prev) => ({
      ...prev,
      [username]: !prev[username]
    }));
  };

  return (
    <aside className="ig-right-sidebar">
      {/* Current User Profile Switch */}
      <div className="ig-profile-switch">
        <div className="ig-profile-switch-info" onClick={onOpenProfile} style={{ cursor: 'pointer' }}>
          <img 
            src={currentUser.avatar} 
            alt={currentUser.username} 
            className="ig-profile-switch-avatar" 
          />
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>{currentUser.username}</div>
            <div style={{ color: 'var(--ig-secondary-text)', fontSize: 13 }}>{currentUser.fullName}</div>
          </div>
        </div>
        <button 
          className="ig-profile-switch-btn"
          onClick={() => alert("Switching accounts is a prototype mockup.")}
        >
          Switch
        </button>
      </div>

      {/* Suggested for you header */}
      <div className="ig-suggestions-header">
        <span className="ig-suggestions-title">Suggested for you</span>
        <button 
          className="ig-suggestions-see-all"
          onClick={() => alert("See all suggestions")}
        >
          See All
        </button>
      </div>

      {/* Suggested accounts list */}
      <div className="ig-suggestions-list">
        {SUGGESTED_USERS.map((user) => {
          const isFollowing = followingMap[user.username];
          return (
            <div key={user.username} className="ig-suggestion-row">
              <div className="ig-suggestion-user">
                <img 
                  src={user.avatar} 
                  alt={user.username} 
                  className="ig-suggestion-avatar" 
                />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{user.username}</div>
                  <div 
                    style={{
                      color: 'var(--ig-secondary-text)',
                      fontSize: 11,
                      maxWidth: 150,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }}
                  >
                    {user.relation}
                  </div>
                </div>
              </div>

              <button 
                className="ig-suggestion-follow-btn"
                style={{ color: isFollowing ? 'var(--ig-primary-text)' : 'var(--ig-blue)' }}
                onClick={() => toggleFollow(user.username)}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Instagram Meta Footer */}
      <div style={{ marginTop: 12 }}>
        <div className="ig-footer-links">
          <span>About</span> • 
          <span>Help</span> • 
          <span>Press</span> • 
          <span>API</span> • 
          <span>Jobs</span> • 
          <span>Privacy</span> • 
          <span>Terms</span> • 
          <span>Locations</span> • 
          <span>Language</span> • 
          <span>Meta Verified</span>
        </div>

        <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div className="ig-footer-copyright">
            © 2026 2AM IDEAS • PROTOTYPE
          </div>
          <div className="watermark-subtle" style={{ fontSize: 11, marginTop: 2 }}>
            <span>Series:</span>
            <strong style={{ color: '#555555' }}>2AM Ideas</strong>
            <span>#01</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
