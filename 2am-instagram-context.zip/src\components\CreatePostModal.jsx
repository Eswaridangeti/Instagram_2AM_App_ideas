import React, { useState } from 'react';
import { CloseIcon, CreateIcon } from './InstagramIcons';

export function CreatePostModal({ isOpen, onClose, onCreatePost, currentUser }) {
  const [caption, setCaption] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [location, setLocation] = useState('');

  if (!isOpen) return null;

  const sampleImages = [
    'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1080&q=80',
    'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1080&q=80',
    'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1080&q=80'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    const finalImage = imageUrl || sampleImages[0];
    onCreatePost({
      username: currentUser.username,
      avatar: currentUser.avatar,
      location: location || 'Creative Studio',
      image: finalImage,
      caption: caption || 'Late night experimentation #2AMAppIdeas',
      likesCount: 1,
      isVerified: false
    });
    onClose();
  };

  return (
    <div className="ig-modal-backdrop animate-fade-in" onClick={onClose} style={{ zIndex: 130 }}>
      <div 
        className="ig-modal-container animate-modal-desktop"
        onClick={(e) => e.stopPropagation()}
        style={{ maxWidth: 480 }}
      >
        <div className="ig-modal-header">
          <h3 className="ig-modal-title">Create new post</h3>
          <button onClick={onClose} style={{ color: 'var(--ig-secondary-text)' }}>
            <CloseIcon size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="ig-modal-body">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src={currentUser.avatar} alt="" style={{ width: 32, height: 32, borderRadius: '50%' }} />
            <span style={{ fontWeight: 600 }}>{currentUser.username}</span>
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-secondary-text)', display: 'block', marginBottom: 4 }}>
              IMAGE URL (OR CHOOSE PRESET)
            </label>
            <input 
              type="text"
              placeholder="Paste Unsplash image URL or click a preset..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                border: '1px solid var(--ig-border)',
                borderRadius: 6,
                fontSize: 13
              }}
            />
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              {sampleImages.map((img, i) => (
                <img 
                  key={i} 
                  src={img} 
                  alt="" 
                  onClick={() => setImageUrl(img)}
                  style={{
                    width: 50,
                    height: 50,
                    borderRadius: 4,
                    objectFit: 'cover',
                    cursor: 'pointer',
                    border: imageUrl === img ? '2px solid #0095f6' : '1px solid #dbdbdb'
                  }} 
                />
              ))}
            </div>
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-secondary-text)', display: 'block', marginBottom: 4 }}>
              LOCATION (OPTIONAL)
            </label>
            <input 
              type="text"
              placeholder="Add location..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                border: '1px solid var(--ig-border)',
                borderRadius: 6,
                fontSize: 13
              }}
            />
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-secondary-text)', display: 'block', marginBottom: 4 }}>
              CAPTION
            </label>
            <textarea 
              rows={3}
              placeholder="Write a caption..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                border: '1px solid var(--ig-border)',
                borderRadius: 6,
                fontSize: 13,
                resize: 'none'
              }}
            />
          </div>

          <div className="ig-modal-footer" style={{ padding: '8px 0 0 0', border: 'none' }}>
            <button type="button" className="ig-btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="ig-btn-primary">
              Share
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
