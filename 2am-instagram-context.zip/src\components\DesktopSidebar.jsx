import React from 'react';
import {
  HomeIcon,
  SearchIcon,
  ExploreIcon,
  ReelsIcon,
  MessagesIcon,
  HeartIcon,
  CreateIcon,
  BookmarkIcon,
  MenuBarsIcon
} from './InstagramIcons';

export function DesktopSidebar({ currentView, setCurrentView, savedCount, currentUser, onOpenCreate }) {
  return (
    <aside className="ig-sidebar">
      <div>
        {/* Brand Logo: 2AM Ideas */}
        <div 
          className="ig-sidebar-logo" 
          onClick={() => setCurrentView('feed')}
          title="2AM Ideas — Save With Context"
        >
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span className="ig-logo-script">2AM Ideas</span>
              <span 
                className="ig-sidebar-text"
                style={{
                  fontSize: 10,
                  fontWeight: 700,
                  background: '#f0f2f5',
                  color: '#262626',
                  padding: '2px 6px',
                  borderRadius: 4,
                  letterSpacing: '0.4px'
                }}
              >
                #01
              </span>
            </div>
            <span 
              className="ig-sidebar-text"
              style={{
                fontSize: 11,
                color: '#737373',
                fontWeight: 500,
                marginTop: 2,
                letterSpacing: '0.2px'
              }}
            >
              Instagram × Save With Context
            </span>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="ig-nav-list">
          <button 
            className={`ig-nav-item ${currentView === 'feed' ? 'active' : ''}`}
            onClick={() => setCurrentView('feed')}
          >
            <HomeIcon active={currentView === 'feed'} size={24} />
            <span className="ig-sidebar-text">Home</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => alert("Search is a visual mockup for this prototype.")}
          >
            <SearchIcon size={24} />
            <span className="ig-sidebar-text">Search</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => alert("Explore is a visual mockup for this prototype.")}
          >
            <ExploreIcon size={24} />
            <span className="ig-sidebar-text">Explore</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => alert("Reels is a visual mockup for this prototype.")}
          >
            <ReelsIcon size={24} />
            <span className="ig-sidebar-text">Reels</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => alert("Messages is a visual mockup for this prototype.")}
          >
            <MessagesIcon size={24} />
            <span className="ig-sidebar-text">Messages</span>
            <span className="ig-nav-badge">2</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => alert("Notifications is a visual mockup for this prototype.")}
          >
            <HeartIcon size={24} />
            <span className="ig-sidebar-text">Notifications</span>
          </button>

          <button 
            className="ig-nav-item"
            onClick={onOpenCreate}
          >
            <CreateIcon size={24} />
            <span className="ig-sidebar-text">Create</span>
          </button>

          {/* Core Feature Tab: Saved */}
          <button 
            className={`ig-nav-item ${currentView === 'saved' ? 'active' : ''}`}
            onClick={() => setCurrentView('saved')}
            style={currentView === 'saved' ? { backgroundColor: 'var(--ig-hover-bg)' } : {}}
          >
            <BookmarkIcon filled={currentView === 'saved'} size={24} />
            <span className="ig-sidebar-text" style={{ fontWeight: currentView === 'saved' ? 700 : 500 }}>
              Saved
            </span>
            {savedCount > 0 && (
              <span className="ig-nav-pill-badge">{savedCount}</span>
            )}
          </button>

          <button 
            className="ig-nav-item"
            onClick={() => setCurrentView('saved')}
          >
            <img 
              src={currentUser.avatar} 
              alt={currentUser.username} 
              style={{
                width: 24, 
                height: 24, 
                borderRadius: '50%', 
                objectFit: 'cover',
                border: currentView === 'profile' ? '2px solid #262626' : '1px solid #dbdbdb'
              }} 
            />
            <span className="ig-sidebar-text">Profile</span>
          </button>
        </nav>
      </div>

      {/* Bottom Area */}
      <div>
        <div 
          style={{ 
            padding: '10px 12px', 
            fontSize: 11, 
            color: '#a8a8a8',
            display: 'flex',
            alignItems: 'center',
            gap: 6
          }}
          className="ig-sidebar-text"
        >
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981' }}></span>
          <span style={{ fontWeight: 600 }}>2AM Ideas</span> #01
        </div>

        <button 
          className="ig-nav-item" 
          onClick={() => alert("Settings & More menu.")}
        >
          <MenuBarsIcon size={24} />
          <span className="ig-sidebar-text">More</span>
        </button>
      </div>
    </aside>
  );
}
